<?php
$conn = mysqli_connect('127.0.0.1','root','','kaifanla');
mysqli_query($conn,"set names utf8");
?>